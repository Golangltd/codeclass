﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class binge : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Click_test()
    {

        Debug.Log("点击测试");

    }
}
